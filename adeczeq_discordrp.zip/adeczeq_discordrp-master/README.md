# pixel_discordrp
Simple script for Discord Rich Presence. Change ID of App and asset's name in client.lua and modify it as you want.
